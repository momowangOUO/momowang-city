import { readFileSync, lstatSync, existsSync } from 'node:fs';
import { resolve, dirname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const root=dirname(fileURLToPath(import.meta.url));
const sha=b=>createHash('sha256').update(b).digest('hex');
function read(name) {
 if(!/^[a-zA-Z0-9_./-]+$/.test(name)||name.split('/').some(p=>!p||p==='.'||p==='..'))throw Error('PATH');
 const path=resolve(root,name);if(!path.startsWith(root+sep))throw Error('PATH');
 let p=path;while(p!==dirname(p)){if(existsSync(p)&&lstatSync(p).isSymbolicLink())throw Error('LINK');p=dirname(p);}
 return readFileSync(path);
}
try {
 const lock=JSON.parse(read('signature.lock.json')),manifest=JSON.parse(read('manifest.json'));
 if(lock.asset_id!==manifest.asset_id||lock.asset_version!==manifest.asset_version||lock.status!==manifest.status)throw Error('IDENTITY');
 for(const [name,digest] of Object.entries(manifest.files))if(sha(read(name))!==digest)throw Error(`CHECKSUM: ${name}`);
 for(const [name,digest] of Object.entries(lock.files))if(sha(read(name))!==digest)throw Error(`LOCK: ${name}`);
 const lines=read('SHA256SUMS').toString().trim().split('\n'),names=new Set();
 for(const line of lines){const m=/^([a-f0-9]{64})  (.+)$/.exec(line);if(!m||names.has(m[2])||sha(read(m[2]))!==m[1])throw Error('CHECKSUM');names.add(m[2]);}
 if(names.size!==Object.keys(manifest.files).length+1||!names.has('manifest.json'))throw Error('COVERAGE');
 console.log(JSON.stringify({ok:true,asset_id:lock.asset_id,version:lock.asset_version,status:lock.status}));
}catch(error){console.error(JSON.stringify({ok:false,error:error.message}));process.exitCode=1;}
