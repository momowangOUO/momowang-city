# 使用规范

唯一轮廓来源是已验收 SVG，唯一规范来源是 spec/signature.yaml。演示图形不代表真实签名。

画布宽度包含 output_padding_height 的透明边距；本体尺寸在 JSON 的 body 中。安全留白是本体高度的倍数，与透明边距不同。
只等比缩放；黑白由同一路径生成；位置使用 anchor_px（以画布左上为原点）。

正式使用必须通过用途审批。屏幕/游戏最小尺寸针对实际显示的本体宽度，不能靠提高纹理分辨率绕过。
游戏不应自动裁切透明边或重置锚点；使用固定版本、manifest 和 signature.lock.json，并运行 node verify.mjs。

AI 海报先生成不含正式签名的主视觉，再由 compose 叠加签名。复杂背景需人工检查可读性。
印刷文件仅是 print-layout / NOT_PREFLIGHTED；RGB 黑不是已验证单黑，白色不是白墨声明。没有 PDF/X、CMYK、专色、叠印或印厂认证承诺。

授权范围见 ASSET_RIGHTS.md。SHA-256 仅证明内容匹配手中清单；必须另行确认清单来源。
