# 可合并到项目 AGENTS.md 的签名规则

先读取 assets/signature.lock.json 并运行 node assets/verify.mjs。
只用本地安装的固定版本素材；禁止重新画签名或使用 main/latest。
保留等比尺寸、透明画布和 JSON 锚点；实际本体显示尺寸不得小于规范。
缺文件、未批准或哈希失败时停止正式使用并报告；禁止替代图、自动修复轮廓或自动升级。
DEMO_ONLY 不可进入产品；正式安装请使用自己的 assets/signature 目录。

本文件供人工合并，安装器不覆盖项目原有 AGENTS.md。
